1.The task has been achieved using javaScript and some instance of jQuery to achieve the effect on pattern.
2.The solution has 4 files : 1. index.html 2. patternTest.js 3.styles.css and 4.readme.txt
3.The task has been achieved using 5 functions which :
    1. initializePatternTest(level) : executes on click of play button
    2. generatePattern(level) : for generating the pattern sequence.
    3. clickedTile(event) : for the user to choose correct tile and does validation whether the sequence is correct or not
    4.setLevel(level): to set the level text of the label
    5.displayPattern (GameTestArray) : to display the captured pattern from the generatePattern(level) method
    6.displayMessage(messageString) : to manipulate the div and display appropriate messages.
    7.completedGame() : to reset the game back to the main state
4. Also, At any point, upon inspecting, in the console, you can find the array of elements which has been generated
(for debugging purposes)
5. the .js file, the .css file are referenced in their respective relative paths inside the html.
6. Lastly, thank you for providing me with this opportunity.