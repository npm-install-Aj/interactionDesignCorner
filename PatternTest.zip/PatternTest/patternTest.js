var eventArray=[];
var GameTestArray=[];
var level;
function initializePatternTest(levelval) {
    level=levelval; //assigning the level
    if(level>10) {
   completedGame();
    }
    
    eventArray=[];
    GameTestArray=[];
    generatePattern(level); //pattern generation as per the level 
    displayPattern(GameTestArray);//array of pattern
   
}
function generatePattern(level)
{
   const eventIdPrefix="square";
   var eventId;
   var randomSquareIndexGenerator;
   setLevel(level);
   for(var i=1;i<=level;i++){
    
    randomSquareIndexGenerator= Math.floor(Math.random() * 4)+1; //generating numbers between 1-4
    eventId = eventIdPrefix+randomSquareIndexGenerator; 
    GameTestArray.push(eventId);//pushing the sequence into the sequence array
    console.log(GameTestArray);
    }
}
//this function for click of the tile 
function clickedTile(event){
    if(GameTestArray.length !=0 && level<=10) //checking if the game has started only then push elements into the array for validation
    {
        if(eventArray.length<=GameTestArray.length) //i.e. pushing till the last element.
        {eventArray.push(event.srcElement.id.toString());
        
        var clickedElement=event.toElement;
        $( clickedElement ).fadeOut(50).fadeIn(50);
        }
        //checking the event arrays.
        if(eventArray.length==GameTestArray.length)
        {
            if(JSON.stringify(eventArray) === JSON.stringify(GameTestArray))
            {
                console.log("YAY level passed!"); 
                eventArray=[];
                GameTestArray=[];
                level++;
                setTimeout(displayMessage("Congratulations! Progress to level "+level+"!"),3000);
                

                setTimeout(initializePatternTest(level),1000); // upon success load the next level
            }
            else //failure result
            {
            console.log("OOps!");
            eventArray=[];
            GameTestArray=[];
            displayMessage("Oops! Start over from level "+1+"!");
            setTimeout(initializePatternTest(1),1000);  // restart from level 1
            }
        }

    
    }
    if(level>10) completedGame();
}
//this function sets the level
function setLevel(num){
    document.getElementById("levelContainer").innerHTML ="<span>Current level <b>"+num+" </b></span>";
    if(num==0){
        document.getElementById("levelContainer").innerHTML ="<span>Current level <b> Completed </b></span>";
    }
   
}
//function to display pattern
function displayPattern(GameTestArray){
    $.each( GameTestArray, function( i, val ) {
       setTimeout( ()=> { $( "#" + val ).fadeOut(500).fadeIn(500);
    }, 1000*i);
     
      });
      
}
function displayMessage(MessageStr){
    document.getElementById("messageContainer").innerHTML ="<span>"+MessageStr+"</span>";
}
function completedGame(){
    generatePattern(0);
    level=0; //resetting the values
    eventArray=[];
    GameTestArray=[];
    displayMessage("Congratulations! you have completed the game press Play to start over");
    document.getElementById("buttonContainer").innerHTML ="<button onclick="+"initializePatternTest(1)"+">Play</button>";
    setLevel(10);
}